Files contained in this directory:
- DMN_Implementation.ipynb
- run.py
- dataset.py
- fetch_babi_data.sh
- fetch_glove_data.sh

What's contained in this file: 
- How to run the code
- Description of each file included in this directory
- Reproduced results

__________________________________________________________________________________________
* How to run the code: 
Open the Python Notebook DMN_Implementation.ipynb in Colab and follow the instruction on the top of each cell. 

Environment: mac.

__________________________________________________________________________________________
* Description of each file included in this directory: 
1) DMN_Implementation.ipynb
In this part of the code, I used the code from this Github repository: https://github.com/jhyuklee/dmn-pytorch. This is a Pytorch implementation of the Dynamic Memory Network introduced in the paper above. It implements the DMN on the bAbI dataset for Question and Answering. 

There are 5 main files included in this repository: 
- utils.py
	prints the stat per epoch during training/validation/testing
- main.py
- model.py
	architecture of DMN is written in here 
- run.py
	runs every epoch
- dataset.py
	pre-process the input words and forms a dictionary of the words occurred in the dataset as well as dictionaries mapping words to word embeddings, etc. The result is saved to a .pkl file.

2) run.py
Slight modification is made in this file. The changes are indicated with the comment #changed in the file. Specifically, I changed the directory to load in the dataset and the word embedding in line 312-315. The original code is commented out.

3) dataset.py
Slight modification is made in this file. The changes are indicated with the comment #changed in the file. Specifically, I changed line 56, which is no longer accepted in the current version of Pytorch.

4) fetch_babi_data.sh, fetch_glove_data.sh
These are taken from https://github.com/DongjunLee/dmn-tensorflow to load in the bAbI dataset as well as the GloVe pre-trained word embeddings. 

__________________________________________________________________________________________
* Reproduced results 
Tasks | Paper DMN Accuracy | Reproduced Accuracy
  1           100                 100 
  2           98.2                16.50
  3           95.2                19.43
  4           100                 100 
  5           99.3                99.51 
  6           100                 90.33 
  7           96.9                99.02 
  8           96.5                /
  9           100                 82.91 
  10          97.5                97.13
  11          99.9                100
  12          100                 100
  13          99.8                100
  14          100                 100
  15          100                 100 
  16          99.4                100
  17          59.6                47.75 
  18          95.3                89.36
  19          34.5                9.47
  20          100                 100









