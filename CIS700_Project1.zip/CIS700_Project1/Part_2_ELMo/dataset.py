import numpy as np
import sys
import pprint
import copy
import pickle
import nltk
import string
import os
from os.path import expanduser
import tensorflow_hub as hub
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import tensorflow as tf

elmo = hub.Module("https://tfhub.dev/google/elmo/2", trainable=True)
init = tf.compat.v1.global_variables_initializer()
nltk.download('punkt')


class Dataset(object):
    def __init__(self, config):
        self.config = config
        self.init_settings()
        self.init_dict()
        self.build_word_dict(self.config.data_dir)
        self.process_data(self.config.data_dir)

    def init_settings(self):
        self.dataset = {}
        self.train_ptr = 0
        self.valid_ptr = 0
        self.test_ptr = 0

    def init_dict(self):
        self.PAD = 'PAD'
        self.word2idx = {}
        self.idx2word = {}
        self.idx2vec = []  # pretrained

        # vector for period .
        self.word2idx['.'] = 0
        self.idx2word[0] = '.'
        self.idx2vec.append([0.0] * self.config.word_embed_dim)

        # vector for ?
        self.word2idx['?'] = 1
        self.idx2word[1] = '?'
        self.idx2vec.append([0.0] * self.config.word_embed_dim)

        # vector for PAD
        self.word2idx['PAD'] = 2
        self.idx2word[2] = 'PAD'
        self.idx2vec.append([0.0] * self.config.word_embed_dim)

        ### try
        self.sen2fileidx = {}
        self.init_word_dict = {}

    # changed
    # update sen2fileidx HERE {exact line from txt: [file, line_idx]}
    # update init_word_dict: {lower case word + suffix: (idx, count)}
    def build_word_dict(self, dir):
        print('### building word dict %s' % dir)
        for subdir, _, files, in os.walk(dir):
            for file in sorted(files):
                with open(os.path.join(subdir, file)) as f:
                    for line_idx, line in enumerate(f):
                        story_idx = int(line.split(' ')[0])

                        # update sen2fileidx HERE {exact line from txt: [file, line_idx]}
                        # update init_word_dict: {lower case word + suffix: (idx, count)}
                        def update_init_dict(line, file, line_idx):
                            words = nltk.word_tokenize(line)
                            if '.' in words or '?' in words:
                                words = words[:-1]

                            if '\n' in line:
                                line = line[:-1]
                            line = line.strip()

                            if line not in self.sen2fileidx:  # line didn't occur before
                                print('line added to sen2fileidx: ', line)
                                self.sen2fileidx[line] = [file, line_idx]
                                for w_idx, word in enumerate(words):
                                    word_suffix = word + '_' + file + ':' + str(line_idx) + '#' + str(w_idx)
                                    # init_word_dict: {lower case word + suffix: (idx, count)}
                                    self.init_word_dict[word_suffix] = (len(self.init_word_dict), 1)

                            else:  # line occurred before
                                prev_file, prev_line_idx = self.sen2fileidx[line]
                                for w_idx, word in enumerate(words):
                                    word_suffix = word + '_' + prev_file + ':' + str(prev_line_idx) + '#' + str(w_idx)
                                    self.init_word_dict[word_suffix] = (
                                        self.init_word_dict[word_suffix][0],
                                        self.init_word_dict[word_suffix][1] + 1)

                        if '\t' in line:  # question / answer
                            question, answer, _ = line.split('\t')
                            question = ' '.join(q.lower() for q in question.split(' ')[1:])
                            update_init_dict(question, file, line_idx)

                            answer = answer.split(',') if ',' in answer else [answer]
                            answer = ' '.join(w.lower() for w in answer)
                            update_init_dict(answer, file, line_idx)

                        else:  # story
                            story_line = ' '.join(s.lower() for s in line.split(' ')[1:])
                            update_init_dict(story_line, file, line_idx)

        print('init dict size', len(self.init_word_dict))
        print('sen2fileidx size: ', len(self.sen2fileidx))
        # print(self.init_word_dict)

    # update word2idx, idx2word, idx2vec occurs HERE
    def map_dict(self, line, type):
        words = nltk.word_tokenize(line)
        if '.' in words or '?' in words:
            words = words[:-1]
        l = len(words)
        output = []

        if '\n' in line:
            line = line[:-1]
        line = line.strip()
        prev_file, prev_line_idx = self.sen2fileidx[line]

        print('map_dict line: ', line)
        # check if this sentence has occurred - sufficient b/c we consider sentence as a whole
        check_word = words[0] + '_' + prev_file + ':' + str(prev_line_idx) + '#' + str(0)
        if check_word in self.word2idx:  # has occurred
            print('has occurred')
            for w_idx, word in enumerate(words):
                word_suffix = word + '_' + prev_file + ':' + str(prev_line_idx) + '#' + str(w_idx)
                output.append(self.word2idx[word_suffix])

        else:  # has NOT occurred
            # print('get vectors')
            embed = elmo([line], signature="default", as_dict=True)["elmo"]
            for idx in range(l):
                with tf.compat.v1.Session() as sess:
                    sess.run(init)
                    # update word2idx, idx2word
                    word_suffix = words[idx] + '_' + prev_file + ':' + str(prev_line_idx) + '#' + str(idx)
                    self.word2idx[word_suffix] = len(self.word2idx)
                    self.idx2word[len(self.idx2word)] = word_suffix
                    self.idx2vec.append(sess.run(embed[0][idx]))
                    output.append(self.word2idx[word_suffix])

        if type == 'question':
            output.append(self.word2idx['?'])
        elif type == 'story':
            output.append(self.word2idx['.'])
        return output

    # changed
    def process_data(self, dir):
        print('\n### processing %s' % dir)
        for subdir, _, files, in os.walk(dir):
            for file in sorted(files):  # loop thru file
                with open(os.path.join(subdir, file)) as f:
                    max_sentnum = max_slen = max_qlen = 0
                    qa_num = file.split('_')[0][2:]
                    set_type = file.split('_')[-1][:-4]
                    story_list = []
                    sf_cnt = 1
                    si2sf = {}
                    total_data = []

                    for line_idx, line in enumerate(f):  # loop thru lines
                        print('line_idx: ', line_idx)
                        line = line[:-1]
                        story_idx = int(line.split(' ')[0])
                        if story_idx == 1:
                            story_list = []
                            sf_cnt = 1
                            si2sf = {}

                        if '\t' in line:  # question
                            question, answer, sup_fact = line.split('\t')
                            question = ' '.join(q.lower() for q in question.split(' ')[1:])
                            q_split = self.map_dict(question, 'question')

                            answer = answer.split(',') if ',' in answer else [answer]
                            answer = ' '.join(w.lower() for w in answer)
                            answer = self.map_dict(answer, 'answer')

                            sup_fact = [si2sf[int(sf)] for sf in sup_fact.split()]

                            sentnum = story_list.count(self.word2idx['.'])
                            max_sentnum = max_sentnum if max_sentnum > sentnum \
                                    else sentnum
                            max_slen = max_slen if max_slen > len(story_list) \
                                    else len(story_list)
                            max_qlen = max_qlen if max_qlen > len(q_split) \
                                    else len(q_split)

                            story_tmp = story_list[:]
                            total_data.append([story_tmp, q_split, answer, sup_fact])

                        else:  # story
                            story_line = ' '.join(l.lower() for l in line.split(' ')[1:])
                            s_split = self.map_dict(story_line, 'story')
                            story_list += s_split
                            si2sf[story_idx] = sf_cnt
                            sf_cnt += 1

                    self.dataset[str(qa_num) + '_' + set_type] = total_data
                    def check_update(d, k, v):
                        if k in d:
                            d[k] = v if v > d[k] else d[k]
                        else:
                            d[k] = v
                    check_update(self.config.max_sentnum, int(qa_num), max_sentnum)
                    check_update(self.config.max_slen, int(qa_num), max_slen)
                    check_update(self.config.max_qlen, int(qa_num), max_qlen)
                    self.config.word_vocab_size = len(self.word2idx)

        print('data size', len(total_data))
        print('max sentnum', max_sentnum)
        print('max slen', max_slen)
        print('max qlen', max_qlen, end='\n\n')

    def pad_sent_word(self, sentword, maxlen):
        while len(sentword) != maxlen:
            sentword.append(self.word2idx[self.PAD])

    def pad_data(self, dataset, set_num):
        for data in dataset:
            story, question, _, _ = data
            self.pad_sent_word(story, self.config.max_slen[set_num])
            self.pad_sent_word(question, self.config.max_qlen[set_num])
        return dataset

    def get_next_batch(self, mode='tr', set_num=1, batch_size=None):
        if batch_size is None:
            batch_size = self.config.batch_size

        if mode == 'tr':
            ptr = self.train_ptr
            data = self.dataset[str(set_num) + '_train']
        elif mode == 'va':
            ptr = self.valid_ptr
            data = self.dataset[str(set_num) + '_valid']
        elif mode == 'te':
            ptr = self.test_ptr
            data = self.dataset[str(set_num) + '_test']

        batch_size = (batch_size if ptr+batch_size <= len(data) else len(data) - ptr)
        padded_data = self.pad_data(copy.deepcopy(data[ptr:ptr+batch_size]), set_num)
        stories = [d[0] for d in padded_data]
        questions = [d[1] for d in padded_data]
        answers = [d[2] for d in padded_data]
        if len(np.array(answers).shape) < 2:
            for answer in answers:
                while len(answer) != self.config.max_alen:
                    answer.append(-100)
        sup_facts = [d[3] for d in padded_data]
        for sup_fact in sup_facts:
            while len(sup_fact) < self.config.max_episode:
                sup_fact.append(self.config.max_sentnum[set_num]+1)
        s_lengths = [[idx+1 for idx, val in enumerate(d[0])
            if val == self.word2idx['.']] for d in padded_data]
        e_lengths = []
        for s_len in s_lengths:
            e_lengths.append(len(s_len))
            while len(s_len) != self.config.max_sentnum[set_num]:
                s_len.append(0)
        q_lengths = [[idx+1 for idx, val in enumerate(d[1])
            if val == self.word2idx['?']][0] for d in padded_data]

        if mode == 'tr':
            self.train_ptr = (ptr + batch_size) % len(data)
        elif mode == 'va':
            self.valid_ptr = (ptr + batch_size) % len(data)
        elif mode == 'te':
            self.test_ptr = (ptr + batch_size) % len(data)

        return (stories, questions, answers, sup_facts,
                s_lengths, q_lengths, e_lengths)

    def get_batch_ptr(self, mode):
        if mode == 'tr':
            return self.train_ptr
        elif mode == 'va':
            return self.valid_ptr
        elif mode == 'te':
            return self.test_ptr

    def get_dataset_len(self, mode, set_num):
        if mode == 'tr':
            return len(self.dataset[str(set_num) + '_train'])
        elif mode == 'va':
            return len(self.dataset[str(set_num) + '_valid'])
        elif mode == 'te':
            return len(self.dataset[str(set_num) + '_test'])

    def init_batch_ptr(self, mode=None):
        if mode is None:
            self.train_ptr = 0
            self.valid_ptr = 0
            self.test_ptr = 0
        elif mode == 'tr':
            self.train_ptr = 0
        elif mode == 'va':
            self.valid_ptr = 0
        elif mode == 'te':
            self.test_ptr = 0

    def shuffle_data(self, mode='tr', set_num=1, seed=None):
        if seed is not None:
            np.random.seed(seed)
        if mode == 'tr':
            np.random.shuffle(self.dataset[str(set_num) + '_train'])
        elif mode == 'va':
            np.random.shuffle(self.dataset[str(set_num) + '_train'])
        elif mode == 'te':
            np.random.shuffle(self.dataset[str(set_num) + '_test'])

    def map_dict2(self, key_list):
        output = []
        for key in key_list:
            word = self.idx2word[key]
            orig_word = word.split('_')[0]
            output.append(orig_word)
        return output

    def decode_data(self, s, q, a, sf, l):
        print(l)
        print('story:', ' '.join(self.map_dict2(s[:l[-1]])))
        print('question:', ' '.join(self.map_dict2(q)))
        print('answer:', self.map_dict2(a))
        print('supporting fact:', sf)
        print('length of sentences:', l)


class Config(object):
    def __init__(self):
        # user_home = expanduser('~')
        self.data_dir = 'datasets/babi/en1'
        # self.data_dir = os.path.join(user_home, 'datasets/babi/en')
        self.word2vec_type = 6  # 6 or 840 (B)
        # self.word2vec_path = 'datasets/glove/glove.6B.300d.txt'
        # self.word2vec_path = expanduser('~') + '/datasets/glove/glove.'\
        #         + str(self.word2vec_type) + 'B.300d.txt'
        self.word_embed_dim = 1024
        self.batch_size = 1
        self.max_sentnum = {}
        self.max_slen = {}
        self.max_qlen = {}
        self.max_episode = 5
        self.word_vocab_size = 0
        self.save_preprocess = True
        self.preprocess_save_path = './data/babi(tmp).pkl'
        self.preprocess_load_path = './data/babi(10k).pkl'


"""
[Version Note]
    v0.1: single max lengths
    v0.2: max length per type, supporting fact index fix
"""

if __name__ == '__main__':
    if not os.path.exists('./data'):
        os.makedirs('./data')

    config = Config()
    if config.save_preprocess:
        dataset = Dataset(config)
        pickle.dump(dataset, open(config.preprocess_save_path, 'wb'))
    else:
        print('## load preprocess %s' % config.preprocess_load_path)
        dataset = pickle.load(open(config.preprocess_load_path, 'rb'))

    # dataset config must be valid
    pp = lambda x: pprint.PrettyPrinter().pprint(x)
    pp(([(k,v) for k, v in vars(dataset.config).items() if '__' not in k]))
    print()

    for set_num in range(1):
        """
        mode = 'tr'
        while True:
            i, t, l = dataset.get_next_batch(mode, set_num+1, batch_size=1000)
            print(dataset.get_batch_ptr(mode), len(i))
            if dataset.get_batch_ptr(mode) == 0:
                print('iteration test pass!', mode)
                break
        mode = 'va'
        while True:
            i, t, l = dataset.get_next_batch(mode, set_num+1, batch_size=100)
            print(dataset.get_batch_ptr(mode), len(i))
            if dataset.get_batch_ptr(mode) == 0:
                print('iteration test pass!', mode)
                break
        """

        mode = 'te'
        dataset.shuffle_data(mode, set_num+1)
        print('done shuffle')
        while True:
            s, q, a, sf, sl, ql, el = dataset.get_next_batch(
                    mode, set_num+1, batch_size=100)
            print(dataset.get_batch_ptr(mode), len(s))
            if dataset.get_batch_ptr(mode) == 0:
                print('s[0]', s[0], 'q[0]', q[0], 'a[0]', a[0], 'sf[0]', sf[0], 'sl[0]', sl[0], 'ql[0]', ql[0], 'el[0]', el[0])
                print('below decode:')
                dataset.decode_data(s[0], q[0], a[0], sf[0], sl[0][:el[0]])
                print('iteration test pass!', mode)
                break
