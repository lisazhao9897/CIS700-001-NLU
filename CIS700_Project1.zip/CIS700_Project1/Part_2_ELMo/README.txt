Files contained in this directory:
- model.py
- dataset.py

What's contained in this file: 
- How to run the code
- Description of each file included in this directory
- Reproduced results

__________________________________________________________________________________________
* How to run the code: 
Open the Python Notebook DMN_Implementation.ipynb that was saved under folder Part_1_reproduce_results (since there are files co-used by the two parts of the project, we wrote the the two sets of code in one Python notebook) in Colab and follow the instruction on the top of each cell. 

Environment: mac.

__________________________________________________________________________________________
* Description of each file included in this directory: 
1) model.py 
Slight modifications are made in this file. The changes are indicated with the comment #changed in the file. Specifically, I converted the words with suffix to the original word when comparing the predicted answers and the target answers. This can be seen in line 222-227. More specific details on the changes can be seen in the pdf file. 

2) dataset.py
Major modifications are made in this file. The changes are described in detail in the pdf file. 

__________________________________________________________________________________________
* Reproduced results 
Tasks | Paper DMN Accuracy | Reproduced Accuracy
  1           100                 100              
  17          47.75               50.39
          













